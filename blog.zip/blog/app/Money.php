<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class Money extends Model{

	
	 protected $table = 'ins_money_back';

}
