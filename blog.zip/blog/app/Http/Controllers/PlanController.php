<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use Illuminate\Http\Request;




class PlanController extends Controller {


	public function index()
	{
		

		return view('plan');
	}
		
		public function create(Request $request)
	{	
		$post=$request->all();
		
		//print_r($post);
		$data=array(
		   'name'=>$post["txtName"],
		   'con'=>$post["txtCondition"],
		   'benifits'=>$post["txtBene"],
		   'remarks'=>$post["txtRemarks"],
		     		
		);
		
		$i=DB::table('ins_plan')->insert($data);
		
	if($i>0){
		\Session::flash('message','successfully Data saved.');
		return redirect('/plan');	
		}
			
	}
			
	


}
