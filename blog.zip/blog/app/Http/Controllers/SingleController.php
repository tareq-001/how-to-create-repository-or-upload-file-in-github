<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use Illuminate\Http\Request;




class SingleController extends Controller {


	public function index()
	{
		$result=DB::table('client_create')->get();
		$result2=DB::table('ins_plan')->get();		
		
		return view('single')->with('pro',$result)->with('plan',$result2);
	}
	public function create(Request $request)
	{	
		$post=$request->all();
		
		//print_r($post);
		$data=array(
		   'clien_id'=>$post["cmbClient"],
		   'plan_id'=>$post["cmbPlan"],
		   'policy'=>$post["txtPolicy"],
		   'years'=>$post["txtYear"],
		   'bouns'=>$post["txtBouns"],
		   'policy_year'=>$post["txtMonth"],
		   'total_amount'=>$post["txtTotal"],
		     		
		);
		
		$i=DB::table('ins_single_back')->insert($data);
		
	if($i>0){
		\Session::flash('message','successfully Data saved.');
		return redirect('/single');	
		}
			
	}







}