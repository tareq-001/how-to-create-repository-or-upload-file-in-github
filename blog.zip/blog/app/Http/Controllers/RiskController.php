<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use Illuminate\Http\Request;

use App\Client;
use App\Money;


class RiskController extends Controller {


	public function index()
	{

		$client_a=Client::all();
		return view('risk',compact('client_a'));
	}

	public function craete5(Request $request){
		$data=Money::select('cmb_plan','id')
		->where('cmb_client',$request->id)
		->take(100)->get();
		
		return response()->json($data);


	}




}