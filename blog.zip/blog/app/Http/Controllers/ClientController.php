<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use Illuminate\Http\Request;

use Illuminate\Pagination\LengthAwarePaginator;


class ClientController extends Controller {


	public function index()
	{
		
		return view('client');
	}
	public function form()
	{
		$result=DB::table('client_create')->paginate(3);		
		//print_r($result);		
		return view('client_view')->with('projects',$result);
	}
	public function create(Request $request)
	{	
		$post=$request->all();
		
		//print_r($post);
		$data=array(
		   'name'=>$post["txtName"],
		   'father'=>$post["txtFather"],
		   'date'=>$post["txtDate"],
		   'age'=>$post["txtAge"],
		   'gender'=>$post["txtGen"],
		   'address'=>$post["txtAddress"],
		   'contact'=>$post["txtContact"],
		   'state'=>$post["txtState"],
		   'country'=>$post["txtCountry"],
		   'city'=>$post["txtCity"],
		   'occup'=>$post["txtOccup"],
		   'salary'=>$post["txtSalary"],
		   'deformity'=>$post["txtDef"],
		   'nominee'=>$post["txtNomi"],
		   'relation'=>$post["txtRela"],   		
		);
		
		$i=DB::table('client_create')->insert($data);
		
	if($i>0){
		\Session::flash('message','successfully Data saved.');
		return redirect('/client');	
		}
			
	}

	public function update(Request $request)
	{
		$post=$request->all();
		
		$data=array(
			'name'=>$post["txtName"],
		   'father'=>$post["txtFather"],
		   'date'=>$post["txtDate"],
		   'age'=>$post["txtAge"],
		   'gender'=>$post["txtGen"],
		   'address'=>$post["txtAddress"],
		   'contact'=>$post["txtContact"],
		   'state'=>$post["txtState"],
		   'country'=>$post["txtCountry"],
		   'city'=>$post["txtCity"],
		   'occup'=>$post["txtOccup"],
		   'salary'=>$post["txtSalary"],
		   'deformity'=>$post["txtDef"],
		   'nominee'=>$post["txtNomi"],
		   'relation'=>$post["txtRela"],
		   	
		);
			$i=DB::table('client_create')->where('id',$post["txtId"])->update($data);
			
			if($i>0){
			
		    return redirect('View_client');	
		
		 }
	}

			
	


}
