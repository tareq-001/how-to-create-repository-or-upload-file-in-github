<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use Illuminate\Http\Request;

use Illuminate\Pagination\LengthAwarePaginator;


class MoneybackController extends Controller {


	public function index()
	{
		$result=DB::table('client_create')->get();
		$result2=DB::table('ins_plan')->get();		
		
		return view('moneyback')->with('pro',$result)->with('plan',$result2);
	}
			
	public function form(){
		$view1=DB::table('ins_money_back')->paginate(5);
		return view('money_view')->with('money',$view1);


	}


			public function create(Request $request)
	{	
		$post=$request->all();
		
		//print_r($post);
		$data=array(
		   'cmb_client'=>$post["cmbClient"],
		   'cmb_plan'=>$post["cmbPlan"],
		   'policy'=>$post["txtPolicy"],
		   'years'=>$post["txtYear"],
		   'bouns'=>$post["txtBouns"],
		   'months'=>$post["txtMonth"],
		   'amounts'=>$post["txtPercent"],
		   'total'=>$post["txtTotal"],
		     		
		);
		
		$i=DB::table('ins_money_back')->insert($data);
		
	if($i>0){
		\Session::flash('message','successfully Data saved.');
		return redirect('/moneyback');	
		}
			
	}

			
	


}
