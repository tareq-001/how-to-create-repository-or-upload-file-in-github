<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/







Route::get('/', 'HomeController@index');
Route::get('Home', 'HomeController@index');


Route::get('client', 'ClientController@index');
Route::get('View_client', 'ClientController@form');
Route::post('create', 'ClientController@create');
Route::get('client_edit/{id}',function($id){
 $row=App\Client::find($id);
 
 return view("client_edit")->with("row",$row);
	
});
Route::get('client_one/{id}',function($id){
 $row=App\Client::find($id);
 return view("client_one")->with("row",$row);
});




Route::post('upto','ClientController@update');

Route::get('plan', 'PlanController@index');
Route::post('create1', 'PlanController@create');


Route::get('moneyback', 'MoneybackController@index');
Route::post('create2', 'MoneybackController@create');
Route::get('moneyview', 'MoneybackController@form');

Route::get('single', 'SingleController@index');

Route::post('create3', 'SingleController@create');
//Artisan::call('up');
Route::get('risk2', 'RiskController@index');

Route::get('risk5', 'RiskController@craete5');






Route::auth();

Route::get('/home', 'HomeController@index');
