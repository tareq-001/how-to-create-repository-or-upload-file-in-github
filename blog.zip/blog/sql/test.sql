-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 17, 2017 at 03:44 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `client_create`
--

CREATE TABLE `client_create` (
  `id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `father` varchar(45) NOT NULL,
  `date` date NOT NULL,
  `age` int(10) NOT NULL,
  `gender` varchar(45) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact` text NOT NULL,
  `state` varchar(45) NOT NULL,
  `country` varchar(45) NOT NULL,
  `city` varchar(45) NOT NULL,
  `occup` varchar(45) NOT NULL,
  `salary` int(10) NOT NULL,
  `deformity` varchar(45) NOT NULL,
  `nominee` varchar(45) NOT NULL,
  `relation` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client_create`
--

INSERT INTO `client_create` (`id`, `name`, `father`, `date`, `age`, `gender`, `address`, `contact`, `state`, `country`, `city`, `occup`, `salary`, `deformity`, `nominee`, `relation`) VALUES
(1, 'sdf', 'sdf', '0000-00-00', 212, 'Male', 'sdfs', 'sdfgsdf', 'sdfg', 'fghfgh', 'sdfg', 'sdfgxxcfdf', 2242, 'sadf', 'sdfsdf', 'sdfsdf'),
(2, 'asdf', 'asdf', '0000-00-00', 21, 'Female', 'rtyeruyrtuyrtu', 'sdf', 'sdfsdf', 'sdf', 'sdfsdf', 'sdfsasdfsdf', 25252, 'saadasdf', 'sdfsdf', 'sdfsdf'),
(3, 'asdadsad', 'asddfgdfg', '0000-00-00', 22, 'Male', 'dfgdfg', 'dfg', 'dfg', 'dfg', 'dfg', 'dfg', 205, 'dfg', 'sdfsdf', 'dfgsdfsdf'),
(4, 'sdf', 'sdfg', '0000-00-00', 23123, 'Male', 'werwer', 'fghfgh', 'fgh', 'fgh', 'fgh', 'fghfffffff', 20, 'sdf', 'sdf', 'sdfwerwer'),
(5, 'sdf', 'sdf', '0000-00-00', 65, 'Female', 'sdf', 'sdf', 'sdf', 'sdf', 'sdf', 'sdf', 5656, 'sdf', 'sdf', 'sdf'),
(6, 'asdf', 'sdf', '0000-00-00', 22, 'Male', 'fdg', 'hjk', 'hjk', 'hjk', 'hjk', 'hjk', 217, 'fghf', 'fgh', 'fgh'),
(7, 'rana', 'taa', '0000-00-00', 25, 'Male', 'sdfsdf', 'sdf', 'sdfsdf', 'sdf', 'sdfsdf', 'sdf', 24998, 'sdf', 'ASas', 'ASas');

-- --------------------------------------------------------

--
-- Table structure for table `ins_money_back`
--

CREATE TABLE `ins_money_back` (
  `id` int(11) NOT NULL,
  `cmb_client` int(11) NOT NULL,
  `cmb_plan` varchar(45) NOT NULL,
  `policy` int(11) NOT NULL,
  `years` int(11) NOT NULL,
  `bouns` int(11) NOT NULL,
  `months` int(11) NOT NULL,
  `amounts` int(11) NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ins_money_back`
--

INSERT INTO `ins_money_back` (`id`, `cmb_client`, `cmb_plan`, `policy`, `years`, `bouns`, `months`, `amounts`, `total`) VALUES
(10, 4, '2', 500000, 5, 5000, 8333, 200000, 705000),
(11, 7, '2', 600000, 25, 22, 2000, 240000, 840022);

-- --------------------------------------------------------

--
-- Table structure for table `ins_plan`
--

CREATE TABLE `ins_plan` (
  `id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `con` varchar(45) NOT NULL,
  `benifits` varchar(45) NOT NULL,
  `remarks` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ins_plan`
--

INSERT INTO `ins_plan` (`id`, `name`, `con`, `benifits`, `remarks`) VALUES
(1, 'gold', '3 yeareasd', '40%kjdf', 'lkjsdlfkj'),
(2, 'sdfs', 'sdfsdf', 'sdf', 'sdf'),
(3, 'dsfg', 'dfg', 'dfg', 'dfg');

-- --------------------------------------------------------

--
-- Table structure for table `ins_single_back`
--

CREATE TABLE `ins_single_back` (
  `id` int(11) NOT NULL,
  `clien_id` varchar(45) NOT NULL,
  `plan_id` varchar(45) NOT NULL,
  `policy` int(11) NOT NULL,
  `years` int(11) NOT NULL,
  `bouns` int(11) NOT NULL,
  `policy_year` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ins_single_back`
--

INSERT INTO `ins_single_back` (`id`, `clien_id`, `plan_id`, `policy`, `years`, `bouns`, `policy_year`, `total_amount`) VALUES
(1, '1', '1', 50000, 1, 2222, 50000, 52222),
(2, '1', '1', 850000, 5, 2, 170000, 850002);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `client_create`
--
ALTER TABLE `client_create`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ins_money_back`
--
ALTER TABLE `ins_money_back`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ins_plan`
--
ALTER TABLE `ins_plan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ins_single_back`
--
ALTER TABLE `ins_single_back`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `client_create`
--
ALTER TABLE `client_create`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `ins_money_back`
--
ALTER TABLE `ins_money_back`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `ins_plan`
--
ALTER TABLE `ins_plan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `ins_single_back`
--
ALTER TABLE `ins_single_back`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
