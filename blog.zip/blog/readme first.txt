1. DownLoad The Blog zipped file and extrect it. 
2. Go blog folder and sql folder.
3. Enter the sql folder and import the sql file database name test.
4. than start xampp and Go browser copy this link- http://localhost/blog/public
-----------------and Enjoy your project-----------------------------------