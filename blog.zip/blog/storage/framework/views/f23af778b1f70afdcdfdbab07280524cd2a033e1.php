<?php $__env->startSection('content'); ?>
<div class="w3-container w3-brown">
  <h1>Create A Plan</h1>
  </div>

<div class="w3-container">

  <div class="w3-green w3-text-deep-purple" style="text-align:center; width:50%; font-size:15px; margin:0px auto;">
    <p><?php echo session('message'); ?></p>
  </div>

</div>

<form class='fomm-horizontal' action="<?php echo e(url('create1')); ?>" method="post">
<input type="hidden" name="_token" value="<?php echo csrf_token()?>" />


<div class="row">
		<div class="col-md-2"><label>Plan Name</label></div>
		<div class="form-group col-md-6">
		<input type="text" name="txtName" class="form-control" required/>
	</div>
</div>

<div class="row">
	<div class="col-md-2"><label>Condition</label></div>
	<div class="form-group col-md-6">
	<input type="text" name="txtCondition" class="form-control" required/>
	</div>
</div>


<div class="row">
	<div class="col-md-2"><label>Benifits</label></div>
	<div class="form-group col-md-6">
	<input type="text" name="txtBene" class="form-control" required/>
	</div>
</div>
<div class="row">
	<div class="col-md-2"><label>Remarks</label></div>
	<div class="form-group col-md-6">
	<textarea name="txtRemarks"></textarea>
	</div>
</div>

<div class="row">
	<div class="col-md-2"><label></label></div>
	<div class="col-sm-2">
       <input type="submit" name="btnSubmit" style="width:200px;"  class="btn btn-success" value="+ Add" />
       </div>
</div>

</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>