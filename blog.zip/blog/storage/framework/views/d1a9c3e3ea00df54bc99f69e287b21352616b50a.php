<?php $__env->startSection('content'); ?>
<div class="w3-container w3-amber">
  <h1>Client Profile</h1>
  </div>
  

   <table class="table">
      <tr ><th colspan="3" style="text-align:center;">Action</th><th>Client ID</th><th>Client Name</th><th>Father/Husbend Name</th><th>Date of Birth</th><th>Age</th><th>Gender</th><th>Address</th> <th>Contact No</th><th>State</th><th>Country</th><th>City</th><th>Occupation</th><th>Salary</th><th>Deformity</th><th>Name of Nominee</th><th>RelationShip</th></tr>
      <?php
        foreach($projects as $project){
		 $token=csrf_token(); 
		 echo "<tr><td><a href='client_one/$project->id' class='btn btn-success btn'>Veiw</a></td><td><a href='client_edit/$project->id' class='btn btn-success btn'>Edit</a></td><td> <a href='#' class='btn btn-danger btn'>Delete</a></td><td>$project->id</td><td>$project->name</td><td>$project->father</td><td>$project->date</td><td>$project->age</td><td>$project->gender</td><td>$project->address</td><td>$project->contact</td><td>$project->state</td><td>$project->country</td><td>$project->city</td><td>$project->occup</td><td>$project->salary</td><td>$project->deformity</td><td>$project->nominee</td><td>$project->relation</td></tr>";	
		}
	  ?>    
  
   </table>
  
<?php echo $projects->render();?>   



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>