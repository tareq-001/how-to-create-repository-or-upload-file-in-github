<?php $__env->startSection('content'); ?>
<div class="w3-container w3-khaki">
  <h1>Create Single Plan</h1>
  </div>

<div class="w3-container">

  <div class="w3-green w3-text-deep-purple" style="text-align:center; width:50%; font-size:15px; margin:0px auto;">
    <p><?php echo session('message'); ?></p>
  </div>

</div>


<form class='fomm-horizontal' action="<?php echo e(url('create3')); ?>" method="post">
<input type="hidden" name="_token" value="<?php echo csrf_token()?>" />


<div class="row">
		<div class="col-md-2"><label>Select Client</label></div>
		<div class="form-group col-md-6">
		<select class="w3-select" name='cmbClient'>
			<?php
        foreach($pro as $pros){
		 $token=csrf_token();
 echo "<option value='$pros->id'>$pros->name</option>";
  	}
	  ?>
		</select>
	</div>
</div>
<div class="row">
		<div class="col-md-2"><label>Select Plan</label></div>
		<div class="form-group col-md-6">
		<select class="w3-select" name='cmbPlan'>
			<?php
        foreach($plan as $plans){
		 $token=csrf_token();
 echo "<option value='$plans->id'>$plans->name</option>";
  	}
	  ?>
		</select>
	</div>
</div>
<div class="row">
	<div class="col-md-2"><label>Policy Amount</label></div>
	<div class="form-group col-md-2">
	<input type="number" name="txtPolicy" class="form-control" id="myText" onKeyup="myFunction()" required/>
	</div>
	<div class="col-md-1"><label>Year Duration</label></div>
	<div class="form-group col-md-1">
	<input type="number" name="txtYear" class="form-control" id="myText2" onKeyup="myFunction()" required/>
	</div>
	<div class="col-md-2"><label>Bouns</label></div>
	<div class="form-group col-md-2">
	<input type="number" name="txtBouns" class="form-control" id="myText3" onKeyup="myFunction()"  required/>
	</div>
</div>
<div class="row">
	<div class="col-md-2"><label>Premium per Year</label></div>
	<div class="form-group col-md-2">
		<input type="text" name="txtMonth" class="form-control" id="demo" readonly/>
	</div>
	<div class="col-md-2"><label>Total Amonut</label></div>
	<div class="form-group col-md-2">
		<input type="text" name="txtTotal" class="form-control" id="demo3" readonly/>
	</div>
	
</div>

<div class="row">
	<div class="col-md-2"><label></label></div>
	<div class="col-sm-2">
       <input type="submit" name="btnSubmit" style="width:200px;"  class="btn btn-success" value="+ Add" />
       </div>
</div>
</form>

<script>
function myFunction() {
    var x = document.getElementById("myText").value;
    var y = document.getElementById("myText2").value;
    var b= document.getElementById("myText3").value;
    z=x/y;
    c=parseInt(x)+parseInt(b);
    document.getElementById("demo").value = z.toFixed(2);
    document.getElementById("demo3").value = c.toString();
}
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>