<?php $__env->startSection('content'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $("#toggle").click(function(){
        $("#para").toggle('slow');
    });
    $("#toggle1").click(function(){
        $("#para1").toggle('slow');
    });
    $("#toggle2").click(function(){
        $("#para2").toggle('slow');
    });
    $("#toggle3").click(function(){
        $("#para3").toggle('slow');
    });
});
</script>

<div class="row">
    <div class="col-lg-6">
        <div class="container">
                <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading" style="font-size:20px; cursor:pointer;">DashBorad</div>

                        <div class="panel-body">
                            <div>
                                <h3>Welcome To Insurance Management System</h3>
                            </div>

                        </div>
                    </div>
                </div>
                 </div>



            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading" id="toggle" style="font-size:20px; cursor:pointer;">Clint Profile<span class="caret"  ></span></div>

                        <div class="panel-body">
                            <div id="para" style="display:none;">
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                            </div>

                        </div>
                    </div>
                </div>
                 </div>
<div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading" id="toggle1" style="font-size:20px; cursor:pointer;">Plan List<span class="caret"  ></span></div>

                        <div class="panel-body">
                            <div id="para1" style="display:none;">
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                            </div>

                        </div>
                    </div>
                </div>
                 </div>


                 <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading" id="toggle3" style="font-size:20px; cursor:pointer;">Money Back Plan Report<span class="caret"  ></span></div>

                        <div class="panel-body">
                            <div id="para3" style="display:none;">
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                            </div>

                        </div>
                    </div>
                </div>
                 </div>



                <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading" id="toggle2" style="font-size:20px; cursor:pointer;">Single Plan Report<span class="caret"></span></div>

                        <div class="panel-body">
                            <div id="para2" style="display:none;">
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                                <div>sakjflkja</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>