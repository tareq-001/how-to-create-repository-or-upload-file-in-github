<?php $__env->startSection('content'); ?>
<div class="w3-container w3-blue">
  <h1>Client Information</h1> 
  </div>

<div class="w3-container w3-light-blue">


	<div class="row">
		<div class="col-md-2 w3-text-teal"><label></label></div>
		<div class="form-group col-md-6">
		<input type="hidden" name="txtId" value="<?php echo $row->id ?>" class="form-control" readonly/>
	</div>
</div>

<div class="row">
		<div class="col-md-3 w3-text-teal"><label><h4>Client Name: </h4> </label></div>
		<div class="form-group col-md-6">
		<h4><?php echo $row->name ?></h4>
	</div>
</div>

<div class="row">
	<div class="col-md-3 w3-text-teal"><label><h4>Father/Husband Name: </h4> </label></div>
	<div class="form-group col-md-6">
	<h4><?php echo $row->father ?></h4>
	</div>
</div>


<div class="row">
	<div class="col-md-2 w3-text-teal"><label><h5>Date of Birth: </h5></label></div>
	<div class="form-group col-md-2">
	<h5><?php echo $row->date ?> </h5>
	</div>
	<div class="col-md-1 w3-text-teal"><label><h5>Age: </h5></label></div>
	<div class="form-group col-md-2">
	<h5><?php echo $row->age ?></h5>
	</div>
</div>



<div class="row">
	<div class="col-md-2 w3-text-teal"><label><h4>Gender: </h4></label></div>
	<div class="form-group col-md-1">
	<h4><?php echo $row->gender ?></h4>
</div>
</div>

<div class="row">
	<div class="col-md-2 w3-text-teal"><label><h5>Address<h5></label></div>
	<div class="form-group col-md-6">
	<h5><?php echo e($row->address); ?></h5>
	</div>
</div>

<div class="row">
	<div class="col-md-2 w3-text-teal"><label><h5>Contact No</h5></label></div>
	<div class="form-group col-md-3">
	<h5><?php echo e($row->contact); ?></h5>
	</div>
	<div class="col-md-2 w3-text-teal"><label><h5>State</h5></label></div>
	<div class="form-group col-md-3">
	<h5><?php echo e($row->state); ?></h5>
	</div>
</div>
<div class="row">
	<div class="col-md-2 w3-text-teal"><label><h5>Country</h5></label></div>
	<div class="form-group col-md-3">
	<h5><?php echo e($row->country); ?></h5>
	</div>
	<div class="col-md-2 w3-text-teal"><label><h5>city</h5></label></div>
	<div class="form-group col-md-3">
	<h5><?php echo e($row->city); ?></h5>
	</div>
</div>

<div class="row">
	<div class="col-md-2 w3-text-teal"><label><h5>Occupation- <h5></label></div>
	<div class="form-group col-md-3">
	<h5><?php echo e($row->occup); ?></h5>
	</div>
	<div class="col-md-2 w3-text-teal"><label><h5>Salary: </h5></label></div>
	<div class="form-group col-md-3">
	<h5><?php echo e($row->salary); ?></h5>
	</div>
</div>

<div class="row">
	<div class="col-md-2 w3-text-teal"><label><h4>Deformity: </h4></label></div>
	<div class="form-group col-md-4">
	<h4> <?php echo e($row->deformity); ?></h4>
	</div>
</div>
<div class="row">
	<div class="col-md-2 w3-text-teal"><label><h5>Name of Nominee: </h5></label></div>
	<div class="form-group col-md-4">
	<h5><?php echo e($row->nominee); ?></h5>
	</div>
	<div class="col-md-2 w3-text-teal"><label><h5>Relationship: </h5></label></div>
	<div class="form-group col-md-4">
	<h5><?php echo e($row->relation); ?></h5>
	</div>
</div>
<div class="row">
	<div class="col-md-2"><label></label></div>
	<div class="col-sm-2">
       <input type="submit" name="btnSubmit" style="width:200px;" onclick="myFunction()" class="btn btn-success" value="Print" />
       </div>
</div>
  </div>




<script>
function myFunction() {
    window.print();
}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>