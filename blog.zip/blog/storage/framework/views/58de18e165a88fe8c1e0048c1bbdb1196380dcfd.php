<?php $__env->startSection('content'); ?>
<div class="w3-container w3-blue-grey">
  <h1>Create A Client</h1> 
  </div>

<div class="w3-container">

  <div class="w3-green w3-text-deep-purple" style="text-align:center; width:50%; font-size:15px; margin:0px auto;">
    <p><?php echo session('message'); ?></p>
  </div>

</div>

<form class='fomm-horizontal' action="<?php echo e(url('create')); ?>" method="post">
<input type="hidden" name="_token" value="<?php echo csrf_token()?>" />


<div class="row">
		<div class="col-md-2"><label>Client Name</label></div>
		<div class="form-group col-md-6">
		<input type="text" name="txtName" class="form-control" required/>
	</div>
</div>

<div class="row">
	<div class="col-md-2"><label>Father/Husband Name</label></div>
	<div class="form-group col-md-6">
	<input type="text" name="txtFather" class="form-control" required/>
	</div>
</div>


<div class="row">
	<div class="col-md-2"><label>Date of Birth</label></div>
	<div class="form-group col-md-2">
	<input type="timeDate" name="txtDate" placeholder="dd/mm/yyyy" class="form-control" required/>
	</div>
	<div class="col-md-1"><label>Age</label></div>
	<div class="form-group col-md-2">
	<input type="number" name="txtAge" class="form-control" required/>
	</div>
</div>



<div class="row">
	<div class="col-md-2"><label>Gender</label></div>
	<div class="form-group col-md-1">
	<input type="radio" name="txtGen" value="Male" required/> Male 
	</div>
	<div class="form-group col-md-1">
	<input type="radio" name="txtGen" value="Female" required/> Female
	</div>
</div>

<div class="row">
	<div class="col-md-2"><label>Address</label></div>
	<div class="form-group col-md-6">
	<textarea name="txtAddress" class="form-control" required/></textarea>
	</div>
</div>

<div class="row">
	<div class="col-md-2"><label>Contact No</label></div>
	<div class="form-group col-md-3">
	<input type="text" name="txtContact" class="form-control" required/>
	</div>
	<div class="col-md-2"><label>State</label></div>
	<div class="form-group col-md-3">
	<input type="text" name="txtState" class="form-control" required/>
	</div>
</div>
<div class="row">
	<div class="col-md-2"><label>Country</label></div>
	<div class="form-group col-md-3">
	<input type="text" name="txtCountry" class="form-control" required/>
	</div>
	<div class="col-md-2"><label>city</label></div>
	<div class="form-group col-md-3">
	<input type="text" name="txtCity" class="form-control" required/>
	</div>
</div>

<div class="row">
	<div class="col-md-2"><label>Occupation</label></div>
	<div class="form-group col-md-3">
	<input type="text" name="txtOccup" class="form-control" required/>
	</div>
	<div class="col-md-2"><label>Salary</label></div>
	<div class="form-group col-md-3">
	<input type="number" name="txtSalary" class="form-control" required/>
	</div>
</div>

<div class="row">
	<div class="col-md-2"><label>Deformity</label></div>
	<div class="form-group col-md-4">
	<input type="text" name="txtDef" class="form-control" required/>
	</div>
</div>
<div class="row">
	<div class="col-md-2"><label>Name of Nominee</label></div>
	<div class="form-group col-md-4">
	<input type="text" name="txtNomi" class="form-control" required/>
	</div>
	<div class="col-md-1"><label>Relationship</label></div>
	<div class="form-group col-md-3">
	<input type="text" name="txtRela" class="form-control" required/>
	</div>
</div>
<div class="row">
	<div class="col-md-2"><label></label></div>
	<div class="col-sm-2">
       <input type="submit" name="btnSubmit" style="width:200px;"  class="btn btn-success" value="+ Add" />
       </div>
</div>

</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>