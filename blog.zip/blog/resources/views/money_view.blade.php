@extends('layout.master')

@section('content')
<div class="w3-container w3-amber">
  <h1>Money Back Plan Report</h1>
  </div>
  

   <table class="table">
      <tr ><th colspan="3" style="text-align:center;">Action</th><th>Client Name</th><th>Plan CODE</th><th>Policy Amount</th><th>No. of Years</th><th>Bouns Amount</th><th>Per months amount</th><th>40% Policy Amonut</th> <th>Total Amount</th></tr>
      <?php
        foreach($money as $row){
		 $token=csrf_token(); 
		 echo "<tr>
     <td><a href='client_one/$row->id' class='btn btn-success btn'>Veiw</a></td>
     <td><a href='client_edit/$row->id' class='btn btn-success btn'>Edit</a></td>
     <td><a href='#' class='btn btn-danger btn'>Delete</a></td>
     <td>$row->cmb_client</td>
     <td>$row->cmb_plan</td>
     <td>$row->policy</td>
     <td>$row->years</td>
     <td>$row->bouns</td>
     <td>$row->months</td>
     <td>$row->amounts</td>
     <td>$row->total</td>
     </tr>";	
		}
	  ?>    
  
   </table>
  
<?php //echo $row->render();?>   



@endsection