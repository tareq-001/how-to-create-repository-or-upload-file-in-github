@extends('layout.master')

@section('content')
<div class="w3-container w3-green">
  <h1>Create risk</h1>
  </div>


<div class="w3-container">

  <div class="w3-green w3-text-deep-purple" style="text-align:center; width:50%; font-size:15px; margin:0px auto;">
    <p>{!! session('message') !!}</p>
  </div>

</div>


<form class='fomm-horizontal' action="{{url('risk2')}}" method="post">
<input type="hidden" name="_token" value="<?php echo csrf_token()?>" />


<div class="row">
		<div class="col-md-2"><label>Select client</label></div>
		<div class="form-group col-md-6">
		<select class="w3-select" name='cmbClient' id='a'>
			<option>select Client</option>
			@foreach($client_a as $cal)
				<option value="{{$cal->id}}">{{$cal->name}}</option>
			@endforeach
		</select>
	</div>
</div>
<div class="row">
		<div class="col-md-2"><label>Select Plan</label></div>
		<div class="form-group col-md-6">
		<select class="abc" name='cmbPlan' id='cmb'>
			<option value='0' disable='true' selected="true">select Plan</option>
			
		</select>
	</div>
</div>
<div class="row">
		<div class="col-md-2"><label>Premium Price: </label></div>
		<div class="form-group col-md-4">
		<input type="number" name="txtPolicy" class="form-control" required/>
	</div>
	<div class="col-md-2"><label>Bonus: </label></div>
		<div class="form-group col-md-4">
		<input type="number" name="txtPolicy" class="form-control" required/>
	</div>
</div>

<div class="row">
	<div class="col-md-2"><label>No 0f Installment</label></div>
	<div class="form-group col-md-2">
	<input type="number" name="txtPolicy" class="form-control" required/>
	</div>
</div>



<div class="row">
	<div class="col-md-2"><label></label></div>
	<div class="col-sm-2">
       <input type="submit" name="btnSubmit" style="width:200px;"  class="btn btn-success" value="+ Add" />
       </div>
</div>
</form>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<script type="text/javascript">
	$(document).ready(function(){
		$(document).on('change','.w3-select',function(){
			//console.log('done');
			var cat_id=$(this).val();
			//console.log(cat_id);
			var div=$(this).parent();
			var op=" ";
			$.ajax({
				type:'get',
				url:'{!!URL::to('risk5')!!}',
				data:{'id':cat_id},
				success:function(data){
					//console.log('success');
					//console.log(data);
					//console.log(data.lenght);
					op+='<option value="0" selected disabled>select plan</option>';
					for(var i=0;i<data.lenght;i++){	
						op+='<option value="'+data[i]+id+'">'+data[i].cmb_client+'</option>';
					}
					div.find('.abc').html(" ");
					div.find('.abc').append(op);


				},
				error:function(){


				}

			});

		});


	});


</script>





@endsection