@extends('layout.master')

@section('content')
<h1>Update Client</h1>


<form class='fomm-horizontal' action="{{url('upto')}}" method="post">
<input type="hidden" name="_token" value="<?php echo csrf_token()?>" />
<div class="row">
		<div class="col-md-2"><label></label></div>
		<div class="form-group col-md-6">
		<input type="hidden" name="txtId" value="<?php echo $row->id ?>" class="form-control" readonly/>
	</div>
</div>

<div class="row">
		<div class="col-md-2"><label>Client Name</label></div>
		<div class="form-group col-md-6">
		<input type="text" name="txtName" value="<?php echo $row->name ?>" class="form-control" required/>
	</div>
</div>

<div class="row">
	<div class="col-md-2"><label>Father/Husband Name</label></div>
	<div class="form-group col-md-6">
	<input type="text" name="txtFather" value="<?php echo $row->father ?>" class="form-control" required/>
	</div>
</div>


<div class="row">
	<div class="col-md-2"><label>Date of Birth</label></div>
	<div class="form-group col-md-2">
	<input type="timeDate" name="txtDate" value="<?php echo $row->date ?>" placeholder="dd/mm/yyyy" class="form-control" required/>
	</div>
	<div class="col-md-1"><label>Age</label></div>
	<div class="form-group col-md-2">
	<input type="number" name="txtAge" value="<?php echo $row->age ?>" class="form-control" required/>
	</div>
</div>



<div class="row">
	<div class="col-md-2"><label>Gender</label></div>
	<div class="form-group col-md-1">
	<input type="radio" name="txtGen"  value="Male" {{$row->gender=='Male'?'checked':''}} required/> Male 
	</div>
	<div class="form-group col-md-1">
	<input type="radio" name="txtGen" value="Female" {{$row->gender=='Female'?'checked':''}} required/> Female
	</div>
</div>

<div class="row">
	<div class="col-md-2"><label>Address</label></div>
	<div class="form-group col-md-6">
	<textarea name="txtAddress" class="form-control" required/>{{$row->address}}</textarea>
	</div>
</div>

<div class="row">
	<div class="col-md-2"><label>Contact No</label></div>
	<div class="form-group col-md-3">
	<input type="text" name="txtContact" value="<?php echo $row->contact  ?>" class="form-control"  required/>
	</div>
	<div class="col-md-2"><label>State</label></div>
	<div class="form-group col-md-3">
	<input type="text" name="txtState" value="<?php echo $row->state ?>" class="form-control" required/>
	</div>
</div>
<div class="row">
	<div class="col-md-2"><label>Country</label></div>
	<div class="form-group col-md-3">
	<input type="text" name="txtCountry"  value="<?php echo $row->country ?>"  class="form-control" required/>
	</div>
	<div class="col-md-2"><label>city</label></div>
	<div class="form-group col-md-3">
	<input type="text" name="txtCity"  value="<?php echo $row->city ?>"  class="form-control" required/>
	</div>
</div>

<div class="row">
	<div class="col-md-2"><label>Occupation</label></div>
	<div class="form-group col-md-3">
	<input type="text" name="txtOccup"  value="<?php echo $row->occup ?>" class="form-control" required/>
	</div>
	<div class="col-md-2"><label>Salary</label></div>
	<div class="form-group col-md-3">
	<input type="number" name="txtSalary" value="<?php echo $row->salary ?>" class="form-control" required/>
	</div>
</div>

<div class="row">
	<div class="col-md-2"><label>Deformity</label></div>
	<div class="form-group col-md-4">
	<input type="text" name="txtDef" value="<?php echo $row->deformity ?>" class="form-control" required/>
	</div>
</div>
<div class="row">
	<div class="col-md-2"><label>Name of Nominee</label></div>
	<div class="form-group col-md-4">
	<input type="text" name="txtNomi" value="<?php echo $row->nominee ?>" class="form-control" required/>
	</div>
	<div class="col-md-1"><label>Relationship</label></div>
	<div class="form-group col-md-3">
	<input type="text" name="txtRela" value="<?php echo $row->relation ?>" class="form-control" required/>
	</div>
</div>
<div class="row">
	<div class="col-md-2"><label></label></div>
	<div class="col-sm-2">
       <input type="submit" name="btnSubmit" style="width:200px;"  class="btn btn-success" value="+ Update" />
       </div>
</div>

</form>


@endsection